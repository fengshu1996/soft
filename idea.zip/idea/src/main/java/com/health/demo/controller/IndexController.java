package com.health.demo.controller;
import java.util.List;
import com.health.demo.model.*;
import com.health.demo.service.impl.QueryDataServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpServletRequest;

@Controller
public class IndexController {

    @Autowired(required = false)
    private QueryDataServiceImpl queryDataService;
    @Autowired(required = false)
    private HttpServletRequest request;


    @RequestMapping("/index")
    public String index(){
        List<TopTopic> topTopics = queryDataService.getNews();
        List<SystemNotice> systemNotices = queryDataService.getNotice();
        List<Links> links = queryDataService.getLinks();
        List<News> topNews = queryDataService.getTopNews();
        List<String> intro = queryDataService.getCenterIntro();

        request.getSession().setAttribute("cx","版主");
        request.getSession().setAttribute("bk","zzz");
        request.getSession().setAttribute("systemNotices",systemNotices);
        request.getSession().setAttribute("topTopics",topTopics);
        request.getSession().setAttribute("links",links);
        request.getSession().setAttribute("topNews",topNews);
        request.getSession().setAttribute("intro",intro);
        return "index";
    }
    @RequestMapping("/logout")
    public String logout(){
        request.removeAttribute("lb");
        request.getSession().removeAttribute("user");
        request.getSession().removeAttribute("userName");
        request.getSession().removeAttribute("username1");
        return "index";
    }


}