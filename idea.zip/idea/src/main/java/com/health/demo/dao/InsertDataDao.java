package com.health.demo.dao;

import com.health.demo.model.User;
import org.apache.ibatis.annotations.Insert;
import org.springframework.stereotype.Repository;

@Repository
public interface InsertDataDao {
    @Insert("insert into yonghuzhuce(yonghuming,mima,xingming,xingbie,chushengnianyue,QQ,youxiang,dianhua,shenfenzheng,touxiang,dizhi,beizhu) " +
            "values('${userName}','${password}','${realName}','${sex}','${brithday}','${qqNumber}'," +
            "'${email}','${telephone}','${idCard}','${portrait}','${address}','${remarks)")
    void userReg(User user);

    @Insert("insert into cj(username,cj,sjbh) values(" +
            "'${userName}',${credit},'${number}')")
    void submit(String userName,float credit,String number);
    @Insert("insert into liuyanban(cheng,xingbie,QQ,youxiang,dianhua,neirong) values(" +
            "'${userName}',${sex},'${qqNumber}','${email}',${telephone},'${remarks}')")
    void insertMessage(User user);
}