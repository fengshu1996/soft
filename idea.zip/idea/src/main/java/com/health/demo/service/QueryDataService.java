package com.health.demo.service;

import com.health.demo.model.*;

import java.util.List;

public interface QueryDataService {
    List<TopTopic> getNews();
    List<SystemNotice> getNotice();
    List<Links> getLinks();
    List<Forum> getPower(User user);
    List<News> getNewsByType(News news);
    List<News> getTopNews();
    List<String> getCenterIntro();
    List<CreateTestPapers> getTestPapers(CreateTestPapers createTestPapers);
    Integer begin(String testPaperId,String userName);
    CreateTestPapers getPapersInfo(Integer id);
    List<ChoiceQuestion> getChoiceQuestion(List<Integer> choiceQuestion);
    void userReg(User user);
    void submit(String userName,float credit,String number);
    List<User> getPsyMessage();
    void insertMessage(User user);
    Integer selectGrade(String userName,String testId);
 }
