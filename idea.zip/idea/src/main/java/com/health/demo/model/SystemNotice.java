package com.health.demo.model;

import lombok.Data;

@Data
public class SystemNotice {
    private Integer id;
    private String type;
    private String content;
}
