package com.health.demo.dao;

import com.health.demo.model.*;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QueryDataDao {
  //查询所有订单信息
  @Select("select top 5 id,biaoti,shouyetupian from xinwentongzhi " +
            "where shouyetupian<>'' and shouyetupian<>'null' order by id desc")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "biaoti", property = "headLine"),
          @Result(column = "shouyetupian", property = "indexPic")
  })
  List<TopTopic> selectNews();

  @Select("select id,leibie,content from dx where leibie='系统公告'")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "leibie", property = "type"),
          @Result(column = "content", property = "content")
  })
  List<SystemNotice> selectNotice();


  List<User> getUser();

  @Select("select id,yonghuming from yonghuzhuce where yonghuming='${userName}' and mima='${password}' and issh='是'")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "yonghuming", property = "userName")
  })
  User check(User user);

  @Select("select top 5* from youqinglianjie where 1=1 order by id desc")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "wangzhanmingcheng", property = "webName"),
          @Result(column = "wangzhi", property = "addr"),
          @Result(column = "addtime", property = "time")
  })
  List<Links> getLinks();

  @Select("select mingcheng from luntanbankuai where banzhu='${userName}'")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "mingcheng", property = "name")
  })
  List<Forum> getPower(User user);

  @Select("select row_number() over(order by id) as aa,id,biaoti,leibie,neirong,tianjiaren,shouyetupian,dianjilv,addtime" +
          " from xinwentongzhi where leibie='${type}' " +
          "and biaoti like '%${keyword}%'" +
          " order by id desc")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "aa", property = "order"),
          @Result(column = "biaoti", property = "tittle"),
          @Result(column = "leibie", property = "type"),
          @Result(column = "neirong", property = "content"),
          @Result(column = "tianjiaren", property = "writer"),
          @Result(column = "shouyetupian", property = "homePagePic"),
          @Result(column = "dianjilv", property = "clickRate"),
          @Result(column = "addtime", property = "addTime")
  })
  List<News> getNewsByType(News news);

  @Select("select top 8 id,shouyetupian,biaoti,addtime from xinwentongzhi where leibie='心灵鸡汤' order by id desc")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "biaoti", property = "tittle"),
          @Result(column = "addtime", property = "addTime"),
          @Result(column = "shouyetupian", property = "homePagePic")
  })
  List<News> getTopNews();
  @Select("select content from dx where leibie='中心简介'")
  List<String> getCenterIntro();

//
  @Select("select id,row_number() over(order by id) as order" +
          ",shijuanbianhao,xuanzeti,tianjiaren,issh,addtime from shijuanshengcheng where issh='是' " +
          "and shijuanbianhao like '%${testPaperId}%' and tianjiaren like '%${writer}%' order by id desc")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "order", property = "order"),
          @Result(column = "shijuanbianhao", property = "testPaperId"),
          @Result(column = "xuanzeti", property = "choiceQuestion"),
          @Result(column = "tianjiaren", property = "writer"),
          @Result(column = "issh", property = "issh"),
          @Result(column = "addtime", property = "addTime")
  })
  List<CreateTestPapers> getTestPapers(CreateTestPapers createTestPapers);


  @Select("select id from cj where sjbh='${testPaperId}' and username='${userName}'")
  Integer begin(String testPaperId,String userName);

  @Select("select id,row_number() over(order by id) as order," +
          "xuanzeti,shijuanbianhao,tianjiaren,issh,addtime from shijuanshengcheng where id=#{id}")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "order", property = "order"),
          @Result(column = "shijuanbianhao", property = "testPaperId"),
          @Result(column = "xuanzeti", property = "choiceQuestion"),
          @Result(column = "tianjiaren", property = "writer"),
          @Result(column = "issh", property = "issh"),
          @Result(column = "addtime", property = "addTime")
  })
  CreateTestPapers getPapersInfo(Integer id);


  @Select("<script>select id,row_number() over(order by id) as order,shiti," +
          "bianhao,nanyichengdu,xuanxiangA,xuanxiangB,xuanxiangC,xuanxiangD,daan,addtime" +
          " from xuanzeti where id in " +
          "<foreach collection='choiceQuestions' item='choiceQuestion' open='(' separator=',' close=')'>" +
          "#{choiceQuestion}" +
          "</foreach>" +
          " order by id</script>")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "order", property = "order"),
          @Result(column = "shiti", property = "testQuestion"),
          @Result(column = "nanyichengdu", property = "difficulty"),
          @Result(column = "bianhao", property = "number"),
          @Result(column = "xuanxiangA", property = "optionA"),
          @Result(column = "xuanxiangB", property = "optionB"),
          @Result(column = "xuanxiangC", property = "optionC"),
          @Result(column = "xuanxiangD", property = "optionD"),
          @Result(column = "daan", property = "daan"),
          @Result(column = "addtime", property = "addTime")
  })
  List<ChoiceQuestion> getChoiceQuestion(@Param("choiceQuestions")List<Integer> choiceQuestions);
  @Select("select id,cheng,xingbie,QQ,youxiang,dianhua,neirong,huifuneirong,addtime " +
          "from liuyanban order by id desc")
  @Results({
          @Result(column = "id", property = "id"),
          @Result(column = "cheng", property = "userName"),
          @Result(column = "xingbie", property = "sex"),
          @Result(column = "QQ", property = "qqNumber"),
          @Result(column = "youxiang", property = "email"),
          @Result(column = "dianhua", property = "telephone"),
          @Result(column = "neirong", property = "remarks"),
          @Result(column = "huifuneirong", property = "reply"),
          @Result(column = "addtime", property = "addTime")
  })
  List<User> getPsyMessage();
  @Select("select ID from cj where username=#{userName} and sjbh=#{testId}")
  Integer selectGrade(String userName,String testId);
}