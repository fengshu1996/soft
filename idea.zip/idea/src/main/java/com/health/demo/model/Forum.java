package com.health.demo.model;

import lombok.Data;

@Data
public class Forum {
    private Integer id;
    private String name;
}
