package com.health.demo.service.impl;

import com.health.demo.dao.InsertDataDao;
import com.health.demo.dao.QueryDataDao;
import com.health.demo.model.*;
import com.health.demo.service.QueryDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QueryDataServiceImpl implements QueryDataService {
    @Autowired(required = false)
    public QueryDataDao queryDataDao;
    @Autowired(required = false)
    public InsertDataDao insertDataDao;
    @Override
    public List<TopTopic> getNews(){
        return queryDataDao.selectNews();
    }
    @Override
    public List<SystemNotice> getNotice(){
        return queryDataDao.selectNotice();
    }

    @Override
    public List<Links> getLinks() {
        return queryDataDao.getLinks();
    }

    @Override
    public List<Forum> getPower(User user) {
        return queryDataDao.getPower(user);
    }

    @Override
    public List<News> getNewsByType(News news) {
        return queryDataDao.getNewsByType(news);
    }
    @Override
    public List<News> getTopNews() {
        return queryDataDao.getTopNews();
    }
    @Override
    public List<String> getCenterIntro(){
        return queryDataDao.getCenterIntro();
    }
    @Override
    public List<CreateTestPapers> getTestPapers(CreateTestPapers createTestPapers){
        return queryDataDao.getTestPapers(createTestPapers);
    }
    @Override
    public Integer begin(String testPaperId, String userName){
        return queryDataDao.begin(testPaperId,userName);
    }
    @Override
    public CreateTestPapers getPapersInfo(Integer id){
        return queryDataDao.getPapersInfo(id);
    }
    @Override
    public List<ChoiceQuestion> getChoiceQuestion(List<Integer> choiceQuestion){
        return queryDataDao.getChoiceQuestion(choiceQuestion);
    }
    @Override
    public void userReg(User user){
        insertDataDao.userReg(user);
    }

    @Override
    public void submit(String userName, float credit, String number) {
        insertDataDao.submit(userName,credit,number);
    }
    @Override
    public List<User> getPsyMessage(){
        return queryDataDao.getPsyMessage();
    }
    @Override
    public void insertMessage(User user){
        insertDataDao.insertMessage(user);
    }
    @Override
    public Integer selectGrade(String userName, String testId){
        return queryDataDao.selectGrade(userName,testId);
    }
}
