package com.health.demo.model;

import lombok.Data;

@Data
public class ChoiceQuestion {
    private Integer id;
    private String order;
    private String number;
    private String difficulty;
    private String testQuestion;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String daan;
    private String addTime;
}
