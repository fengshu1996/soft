package com.health.demo.service;

import com.health.demo.model.User;

import java.util.List;

public interface UserService {
    User check(User user);
    List<User> getUser();
}
