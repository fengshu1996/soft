package com.health.demo.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.health.demo.model.ChoiceQuestion;
import com.health.demo.model.CreateTestPapers;
import com.health.demo.model.News;
import com.health.demo.model.User;

import com.health.demo.service.impl.QueryDataServiceImpl;
import com.health.demo.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {
    @Autowired(required = false)
    private UserServiceImpl userService;
    @Autowired
    private HttpServletRequest request;
    @Autowired(required = false)
    private QueryDataServiceImpl queryDataService;

    @RequestMapping("/checkUser")
    public String getUser(User user){
        User user1 = userService.check(user);
        if (user1 != null){
            request.getSession().setAttribute("user",user1);
            request.getSession().setAttribute("userName",user1.getUserName());
        }
        return "index";
    }


    @RequestMapping("/getNewsByType")
    public String getNews(String lb, String keyword,
                          @RequestParam(value="page",defaultValue="1",required=true) String page,
                          @RequestParam(value="pageSize",defaultValue="20",required=true) String pageSize){
        request.setAttribute("lb",lb);
        News news = new News();
        news.setType(lb);
        news.setKeyword(keyword);
        if ("0".equals(page)){
            page = "1";
        }
        Page<News> startPage = PageHelper.startPage(Integer.parseInt(page),Integer.parseInt(pageSize));
        startPage.setOrderBy("id");
        List<News> newsList = queryDataService.getNewsByType(news);
        PageInfo newsListPage = new PageInfo(newsList);
        request.getSession().setAttribute("newsListPage",newsListPage);
        return "news";
    }
    @RequestMapping("/getInfor")
    public String getInfor(CreateTestPapers createTestPapers,
            @RequestParam(value="page",defaultValue="1",required=true) String page,
            @RequestParam(value="pageSize",defaultValue="20",required=true) String pageSize){
        if ("0".equals(page)){
            page = "1";
        }
        if (createTestPapers.getTestPaperId()==null){
            createTestPapers.setTestPaperId("");
        }
        if (createTestPapers.getWriter()==null){
            createTestPapers.setWriter("");
        }
        User user = (User) request.getSession().getAttribute("user");
        if (user==null){
            user = new User();
            user.setUserName("");
        }
        PageHelper.startPage(Integer.parseInt(page),Integer.parseInt(pageSize));
        List<CreateTestPapers> testPapers1 = queryDataService.getTestPapers(createTestPapers);
        List<CreateTestPapers> testPapers = new ArrayList<>();
        for (CreateTestPapers testPaper:testPapers1) {
            Integer integer = queryDataService.begin(testPaper.getTestPaperId(),user.getUserName());
            if (integer!=null){
                testPaper.setFlag("1");
            }else {
                testPaper.setFlag("0");
            }
            testPapers.add(testPaper);
        }
        PageInfo testPapersInfo = new PageInfo(testPapers);
        request.getSession().setAttribute("testPapersInfo",testPapersInfo);
        return "xinliceshi";
    }
    @RequestMapping("/getPapersInfo")
    public String getPapersInfo(String id){
        CreateTestPapers paperInfo = queryDataService.getPapersInfo(Integer.parseInt(id));
        request.getSession().setAttribute("paperInfo",paperInfo);
        String[] nums = paperInfo.getChoiceQuestion().split(",");
        List<Integer> list = new ArrayList<>();
        for (int i=0;i<nums.length;i++){
            list.add(Integer.parseInt(nums[i]));
        }
        List<ChoiceQuestion> choiceQuestions =
                queryDataService.getChoiceQuestion(list);
        request.getSession().setAttribute("choiceQuestions",choiceQuestions);
        return "shijuan_detail";
    }
    @RequestMapping("/sunmit")
    public String sunmit(String xztshitida1,String xztxxa1,
                       String xztshitida2,String xztxxa2,
                       String xztshitida3,String xztxxa3,
                       String xztshitida4,String xztxxa4,
                       String xztshitida5,String xztxxa5,
                       String xztshitida6,String xztxxa6,
                       String xztshitida7,String xztxxa7,
                       String xztshitida8,String xztxxa8,
                       String xztshitida9,String xztxxa9,
                       String xztshitida10,String xztxxa10,
                       String userName,String bianhao){
        float df = 0;
        for (int i=1;i<=10;i++) {
            String tmp1 = "xztshitida"+String.valueOf(i);
            String tmp2 = "xztxxa"+String.valueOf(i);
            if(tmp1!=null||tmp2!=null)
            {
                if(tmp1.equals(tmp2))
                {
                    df=df+10;
                }
            }
        }
        Integer id = queryDataService.selectGrade(userName,bianhao);
        if (id==null){
            queryDataService.submit(userName,df,bianhao);
        }
        return "xinliceshi";
    }
    @RequestMapping("/userReg")
    public String userReg(User user){
        queryDataService.userReg(user);
        return "index";
    }
    @RequestMapping("/psyMessage")
    public String psyMessage(User user,
                             @RequestParam(value="page",defaultValue="1",required=true) String page,
                             @RequestParam(value="pageSize",defaultValue="20",required=true) String pageSize){
        if ("0".equals(page)){
            page = "1";
        }
        PageHelper.startPage(Integer.parseInt(page),Integer.parseInt(pageSize));
        List<User> psyMessage = queryDataService.getPsyMessage();
        PageInfo psyMessages = new PageInfo(psyMessage);
        request.getSession().setAttribute("psyMessages",psyMessages);
        return "lyblist";
    }
    @RequestMapping("/insertMessage")
    public void insertMessage(User user){
        queryDataService.insertMessage(user);
    }
}
