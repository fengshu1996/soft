package com.health.demo.model;

import lombok.Data;

@Data
public class User {
    private Integer id;
    private String userName;
    private String password;
    private String realName;
    private String sex;
    private String registration;
    private String qqNumber;
    private String email;
    private String brithday;
    private String telephone;
    private String portrait;
    private String idCard;
    private String address;
    private String remarks;
    private String issh;
    private String CX;
    private String addTime;
    private String reply;
}
