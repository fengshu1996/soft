package com.health.demo.model;

import lombok.Data;

@Data
public class News {
    private Integer id;
    private String tittle;
    private String order;
    private String type;
    private String content;
    private String writer;
    private String homePagePic;
    private String clickRate;
    private String addTime;
    private String keyword;
}
