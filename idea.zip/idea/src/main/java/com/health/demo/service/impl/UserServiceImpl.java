package com.health.demo.service.impl;

import com.health.demo.dao.QueryDataDao;
import com.health.demo.model.User;
import com.health.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImpl implements UserService {
    @Autowired(required = false)
    public QueryDataDao queryDataDao;

    @Override
    public User check(User user) {
        return queryDataDao.check(user);
    }

    @Override
    public List<User> getUser() {
        return queryDataDao.getUser();
    }
}
