package com.health.demo.model;

import lombok.Data;


@Data
public class CreateTestPapers {
    private Integer id;
    private String order;
    private String testPaperId;
    private String choiceQuestion;
    private String writer;
    private String issh;
    private String addTime;
    private String flag;

}
